from eppy.modeleditor import IDF

IDD_FILE = "C:\\EnergyPlusV23-1-0\\Energy+.idd"
DATA_FOLDER = "G:\\My Drive\\presentations\\CMU\\12770 - Autonomous Sustainable Buildings From Theory to Practice\\Chapter 10 - Building Energy Simulations\\material\\"
IDF_FILE = DATA_FOLDER + "My First EnergyPlus.idf"
EPW_FILE = "C:\\EnergyPlusV23-1-0\\WeatherData\\USA_PA_Pittsburgh.Intl.AP.725200_TMY3.epw"

IDF.setiddname(IDD_FILE)
idf = IDF(IDF_FILE, EPW_FILE)
idf.run(expandobjects = True, readvars = True)

