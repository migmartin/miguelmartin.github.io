from pyenergyplus.plugin import EnergyPlusPlugin
from statistics import mean

class MyControlSystem(EnergyPlusPlugin):
    """
    Class representing my control system in the building.
    """

    def __init__(self):
        super().__init__()
        self.winter_setpoint = 19
        self.summer_setpoint = 24
        self.delta_temperature = 2.0
        self.need_to_get_handles = True
        self.zone_1_air_temperature_handle = None
        self.zone_2_air_temperature_handle = None
        self.zone_3_air_temperature_handle = None
        self.hvac_schedule_handle = None


    def on_begin_zone_timestep_before_set_current_weather(self, state) -> int:
        """
        Called when a timestep begins before setting the current weather (i.e. callback function).
        :param state: An active EnergyPlus “state” that is returned from a call to api.state_manager.new_state().
        :return: Nothing
        """
        if self.api.exchange.api_data_fully_ready(state):
            if self.need_to_get_handles:
                self.zone_1_air_temperature_handle = self.api.exchange.get_variable_handle(state, "Zone Mean Air Temperature", "THERMAL ZONE 1")
                self.zone_2_air_temperature_handle = self.api.exchange.get_variable_handle(state, "Zone Mean Air Temperature", "THERMAL ZONE 2")
                self.zone_3_air_temperature_handle = self.api.exchange.get_variable_handle(state, "Zone Mean Air Temperature", "THERMAL ZONE 3")
                self.hvac_schedule_handle = self.api.exchange.get_actuator_handle(state, "Schedule:Compact", "Schedule Value", "HVAC SCHEDULE")
                self.need_to_get_handles = False
            current_month = self.api.exchange.month(state)
            indoor_air_temperature = mean([self.api.exchange.get_variable_value(state, self.zone_1_air_temperature_handle),
                                           self.api.exchange.get_variable_value(state, self.zone_2_air_temperature_handle),
                                           self.api.exchange.get_variable_value(state, self.zone_3_air_temperature_handle)])
            if current_month in [12, 1, 2, 3]: # Winter months
                self.api.exchange.set_actuator_value(state, self.hvac_schedule_handle, 0)
                if indoor_air_temperature < (self.winter_setpoint - self.delta_temperature):
                    self.api.exchange.set_actuator_value(state, self.hvac_schedule_handle, 1)
                elif indoor_air_temperature > self.winter_setpoint:
                    self.api.exchange.set_actuator_value(state, self.hvac_schedule_handle, 0)
                else:
                    pass
            elif current_month in [6, 7, 8, 9]: # Summer months
                if indoor_air_temperature < self.summer_setpoint:
                    self.api.exchange.set_actuator_value(state, self.hvac_schedule_handle, 0)
                elif indoor_air_temperature > (self.summer_setpoint + self.delta_temperature):
                    self.api.exchange.set_actuator_value(state, self.hvac_schedule_handle, 1)
                else:
                    pass
            else:
                self.api.exchange.set_actuator_value(state, self.hvac_schedule_handle, 0)
            return 0
        else:
            return 0

